## hackathon algorithm package

This library implements varies algorithms
For sorting , calculating elements in an array
The fibonacci function to find nth fibonacci value
The function to compute a factorial of the number

## installing this package locally
`pip install setup.py sdist`

## installing this package from github
`pip install git+https://github.com/zingm/hackathon.git`

## updating this package from github

`pip install --upgrade+https://github.com/zingm/hackathon.git`
